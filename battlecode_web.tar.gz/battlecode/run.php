<html>
<head>
<title>BoydBoyd></title>
<meta http-equiv="refresh" content="0;url=index.php">
</head>
<body>

<?php
require "setup.php";

$team_a = $_POST["team_a"];
$team_b = $_POST["team_b"];

if (!$auth) {
	echo "You are not allowed to view this page.";
} else {
	echo "<a href=\"index.php\">back</a><br><br>";

	if ($team_a == "") {
		die('Team A is blank');
	} else if ($team_b == "") {
		die('Team B is blank');
	}

	mysql_query("INSERT INTO queue (team_a, team_b) VALUES (\"" . $team_a . "\", \"" . $team_b . "\")");
	echo "Successfully queued the matches.<br>";
}
	

?>
</body>
</html>
