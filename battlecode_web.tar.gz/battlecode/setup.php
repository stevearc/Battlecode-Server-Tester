
<?php
# Get the current user
$user_email = $_SERVER["SSL_CLIENT_S_DN_Email"];
$username = substr($user_email, 0, strpos($user_email, "@"));

# Load config file
$config_file = "/etc/battlecode.conf";
$comment = "#";
$fp = fopen($config_file, "r");
while (!feof($fp)) {
	$line = trim(fgets($fp));
	if ($line && !ereg("^$comment", $line)) {
		$pieces = explode("=", $line);
		$option = trim($pieces[0]);
		$value = trim($pieces[1]);
		$config_values[$option] = $value;
	}
}
fclose($fp);

$database = $config_values['DATABASE'];
$db_user = $config_values['DB_USER'];
$db_pass = $config_values['DB_PASS'];
$version_control = $config_values['VERSION_CONTROL'];
$auth = false;

if ($config_values['AUTHORIZED_USERS'] == "all") {
	$auth = true;
} else {
	$authorized_users = explode(",",$config_values['AUTHORIZED_USERS']);
	if (in_array($username, $authorized_users))
		$auth = true;
}


$con = mysql_connect("localhost",$db_user,$db_pass);
if (!$con){
	die('Could not connect: ' . mysql_error());
}
mysql_select_db($database, $con);
