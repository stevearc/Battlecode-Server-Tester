<html>
<head>
<title>BoydBoyd></title>
<meta http-equiv="refresh" content="0;url=index.php">
</head>
<body>

<?php
require "setup.php";

$runid = $_GET['runid'];

if (!$auth) {
	echo "You are not allowed to view this page.";
} else {
	if ($runid != ""){
		mysql_query("INSERT INTO delete_queue (id) VALUES (" . $runid . ")");
		echo "Run " . $runid . " deleted<br><br>";
		echo "<a href=\"index.php\">back</a>";
	}
}

mysql_close($con);
?>
</body>
</html>
