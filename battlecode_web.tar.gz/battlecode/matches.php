<html>
<head>
<title>BoydBoyd</title>
<meta http-equiv="refresh">
</head>
<body>

<?php
require "setup.php";

if (!$auth) {
	echo "You are not allowed to view this page.";
} else {
	$runid = $_GET['id'];
	if ($runid == "") {
		echo "No run selected<br>";
	} else {
		$sql = "SELECT id, team_a, t1.alias a_nick, team_b, t2.alias b_nick FROM runs r LEFT JOIN tags t1 ON r.team_a = t1.tag LEFT JOIN tags t2 ON r.team_b = t2.tag WHERE id = " . $runid;
		$query = mysql_query($sql);
		$row = mysql_fetch_array($query);
		echo "<a href=\"index.php\">back</a><br><br>";
		echo "<table border=\"0\">";
		echo "<tr>";
		echo "<th>Team A</th>";
		echo "<th>Team B</th>";
		echo "<tr>";

		if ($row['a_nick'] != "")
			echo "<td>" . $row['a_nick'] . " (" . $row['team_a'] . ")</td>";
		else	
			echo "<td>" . $row['team_a'] . "</td>";
		
		if ($row['b_nick'] != "")
			echo "<td>" . $row['b_nick'] . " (" . $row['team_b'] . ")</td>";
		else	
			echo "<td>" . $row['team_b'] . "</td>";
		echo "</tr>";
		$sql = "SELECT SUM(win) AS wins FROM matches WHERE id = " . $runid;
		$query = mysql_query($sql);
		$row = mysql_fetch_array($query);
		$wins = $row['wins'];
		$sql = "SELECT COUNT(*) AS total FROM matches WHERE id = " . $runid;
		$query = mysql_query($sql);
		$row = mysql_fetch_array($query);
		$total = $row['total'];
		$losses = $total - $wins;
		echo "<tr>";
		echo "<td>" . $wins . "</td>";
		echo "<td>" . $losses . "</td>";
		echo "</tr>";
		echo "</table><br><br>";
		echo "<table border=\"1\">";
		echo "<tr>";
		echo "<th>Map</th>";
		echo "<th>Winner</th>";
		echo "<th>Match</th>";
		echo "</tr>";
		$sql = "SELECT * FROM matches WHERE id = " . $runid . " ORDER BY map";
		$query = mysql_query($sql);
		while ($row = mysql_fetch_array($query)) {
			echo "<tr>";
			echo "<td>" . $row['map'] . "</td>";
			if ( $row['win'] == 1 ) {
				echo "<td>A</td>";
			} else {
				echo "<td>B</td>";
			}
			$filename = substr($row['file'], strrpos($row['file'], "/")+1);
			echo "<td> <a href=\"matches/" . $filename . "\">download</a></td>";
		}
		echo "</table>";
	}

mysql_close($con);
}
?>

</body>
</html>
