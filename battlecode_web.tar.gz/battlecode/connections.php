<html>
<head>
<title>BoydBoyd</title>
<meta http-equiv="refresh" content="30">
</head>
<body>

<?php
require "setup.php";

if (!$auth) {
	echo "You are not allowed to view this page.";
} else {
	echo "<a href=\"index.php\">back</a><br><br>";
	echo "<table border=\"1\">";
	echo "<tr>";
	echo "<th>Client</th>";
	echo "<th>Map</th>";
	echo "<th>Time</th>";
	echo "</tr>";
	$sql = "SELECT addr, map, timediff(now(),modified) AS diff FROM connections c LEFT JOIN running_matches r ON c.id = r.conn_id ORDER BY addr, map";
	$query = mysql_query($sql);
	while ($row = mysql_fetch_array($query)) {
		echo "<tr>";
		echo "<td>" . $row['addr'] . "</td>";
		echo "<td>" . $row['map'] . "</td>";
		echo "<td>" . $row['diff'] . "</td>";
		echo "</tr>";
	}
	echo "</table>";
	mysql_close($con);
}
?>
</body>
</html>
