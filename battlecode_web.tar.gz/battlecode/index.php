<html>
<head>
<title>BoydBoyd</title>
<meta http-equiv="refresh" content="30">
</head>
<body>
<?php
require "setup.php";

if (!$auth) {
	echo "You are not allowed to view this page.";
} else {
	$search = $_GET["search"];
	if ($search != "")
		echo "<a href=\"index.php\">home</a><br><br>";
	if ($version_control == "git") {
		echo "Enter the revision tag or SHA hash as a team";
	} else if ($version_control == "svn") {
		echo "Enter the svn revision number as a team";
	} 
?>
<form action="run.php" method="post">
	<P>
		<label for="team_a">Team A<label>
			<input type="text" name="team_a" id="team_a" size="15"><br>
		<label for="team_b">Team B<label>
			<input type="text" name="team_b" id="team_b" size="15"><br>
		<input type="submit" value="Run" name="submit"><br> 
	</P>
</form>

<form action="compare.php" method="post">
	<P>
		<label for="runid1">Run ID 1<label>
			<input type="text" name="runid1" id="runid1" size="3"><br>
		<label for="team_b">Run ID 2<label>
			<input type="text" name="runid2" id="runid2" size="3"><br>
		<input type="submit" value="Compare"><br> 
	</P>
</form>

<form action="index.php" method="get">
	<P>
		<label for="Search"><label>
			<input type="text" name="search" id="search" size="15"><br>
		<input type="submit" value="Search"><br> 
	</P>
</form>

<?
if ($version_control == "svn") {
?>
<form action="tag.php" method="post">
	<P>
		<label for="Revision">Revision:<label>
			<input type="text" name="rev" id="rev" size="3">
		<label for="Tag">Tag:<label>
			<input type="text" name="tag" id="tag" size="15"><br>
		<input type="submit" value="Tag"><br> 
	</P>
</form>
<?
}
?>

<a href="connections.php">connections</a>
<?
		echo "<table border=\"1\">";
		echo "<tr>";
		echo "<th>Run ID</th>";
		echo "<th>Team A</th>";
		echo "<th>Team B</th>";
		echo "<th>Wins</th>";
		echo "<th>Matches</th>";
		echo "<th>Status</th>";
		echo "<th>Control</th>";
		echo "<th>Time</th>";
		echo "</tr>";
		// Display the queued runs
		$sql = "SELECT * FROM queue ORDER BY id DESC";
		$query = mysql_query($sql);
		while ($row = mysql_fetch_array($query)) {
			echo "<tr>";
			echo "<td>?</td>";
			if ($aliases[$row['team_a']] != "")
				echo "<td>" . $aliases[$row['team_a']] . " (" . $row['team_a'] . ")</td>";
			else
				echo "<td>" . $row['team_a'] . "</td>";
			
			if ($aliases[$row['team_b']] != "") 
				echo "<td>" . $aliases[$row['team_b']] . " (" . $row['team_b'] . ")</td>";
			else 
				echo "<td>" . $row['team_b'] . "</td>";
		
			echo "<td>0</td>";
			echo "<td>matches</td>";
			echo "<td>queued</td>";
			echo "<td><a href=\"dequeue.php?id=" . $row['id'] . "\">cancel</a></td>";
			echo "</tr>";
		}
		

		// Display the current runs
		$sql = "SELECT id, team_a, t1.alias a_nick, team_b, t2.alias b_nick, timediff(ended, started) as taken, timediff(now(), started) as sofar FROM runs r LEFT JOIN tags t1 ON r.team_a = t1.tag LEFT JOIN tags t2 ON r.team_b = t2.tag";
		if ($search != "") {
			$sql = $sql . " WHERE team_a RLIKE \".*" . $search . ".*\" OR team_b RLIKE \".*" . $search . ".*\"";
			$sql = $sql . " OR t1.alias RLIKE \".*" . $search . ".*\" OR t2.alias RLIKE \".*" . $search . ".*\"";
		}
		$sql = $sql . " ORDER BY id DESC";
		$run_query = mysql_query($sql);
		while ($row = mysql_fetch_array($run_query)){
			$sql = "SELECT COUNT(*) AS total FROM matches WHERE id = " . $row['id'];
			$query = mysql_query($sql);
			$sub_row = mysql_fetch_array($query);
			$maps = $sub_row['total'];
			$sql = "SELECT SUM(win) AS wins FROM matches WHERE id = " . $row['id'];
			$query = mysql_query($sql);
			$sub_row = mysql_fetch_array($query);
			$wins = $sub_row['wins'];
			if ( $wins == "" ) {
				$wins = 0;
			}
			echo "<tr>";
			echo "<td>" . $row['id'] . "</td>";
			if ($row['a_nick'] != "")
				echo "<td>" . $row['a_nick'] . " (" . $row['team_a'] . ")</td>";
			else
				echo "<td>" . $row['team_a'] . "</td>";
			
			if ($row['b_nick'] != "") 
				echo "<td>" . $row['b_nick'] . " (" . $row['team_b'] . ")</td>";
			else 
				echo "<td>" . $row['team_b'] . "</td>";
		
			echo "<td>" . $wins . "/" . $maps . "</td>";
			echo "<td><a href=\"matches.php?id=" . $row['id'] . "\">matches</a></td>";
			if ($row['finished'] == 1) 
				echo "<td>Complete</td>";
			else
				echo "<td>Running </td>";
			echo "<td><a href=\"delete.php?runid=" . $row['id'] . "\" onclick=\"return confirm('Are you sure? This will delete all the match files from this run.')\">delete</a></td>";
			if ($row['finished'] == 1) 
				echo "<td>" . $row['taken'] . "</td>";
			 else 
				echo "<td>" . $row['sofar'] . "</td>";
			
			echo "</tr>\n";
		}
		echo "</table><br>";

		mysql_close($con);
		}
		?>
</body>
</html>
