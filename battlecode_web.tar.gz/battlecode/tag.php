<html>
<head>
<title>Battlecode</title>
<meta http-equiv="refresh" content="1;url=index.php">
</head>
<body>

<?php
require "setup.php";

if (!$auth) {
	echo "You are not allowed to view this page.";
} else {
	$rev = $_POST['rev'];
	$tag = $_POST['tag'];
	if ($rev == "") {
		echo "No revision selected<br>";
	} else if ($tag == "") {
		echo "Must enter a valid tag name.";
	} else {
		$sql = "UPDATE tags SET alias = \"" . $tag . "\" WHERE tag = \"" . $rev . "\"";
		$query = mysql_query($sql);
	}
}

mysql_close($con);

?>

</body>
</html>
