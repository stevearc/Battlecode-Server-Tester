##################
## REQUIREMENTS ##
##################
You need four things in order for this system to work properly:
	* Apache server with php
	* MySQL server
	* Git or SVN
	* Java and Ant (to run the battlecode client)

##############
## DATABASE ##
##############
Create a new user and database in MySQL.
After you do that, the setup commands are all in etc/db.sql, so you can simply run:
	mysql -u [user] -p [database] < etc/db.sql

################
## WEB SERVER ##
################
Unzip the battlecode directory in some subdirectory of your apache root.  
You will need to create a symbolic link from the directory you are storing the match files in to a new folder called "matches".  

# Access Control
You can either use SSL and check the certificates of users or use some sort of password protection, like a .htaccess file.  
You can configure your access options in the battlecode.conf file.  If you choose SSL with certs, you will need to set go through the following setup:

# SSL
This section makes many references to the files in etc/apache2.
Make sure the configuration in ports.conf is copied to your /etc/apache2 folder.
In etc/apache2/ssl there are instructions for generating a SSL key for your server.
Put the resulting server.crt, server.csr, server.key, and server.key.encrypted in /etc/apache2/ssl (make the directory if necessary)
Copy the file in sites-available to /etc/apache2/sites-available and make a symlink to it from /etc/apache2/sites-enabled.
You will need to edit this file.  Change the DocumentRoot where you want your https home directory to be.  
Also alter the <Directory /var/www-ssl/> line to reflect that change.

#####################
## VERSION CONTROL ##
#####################
To run a client or server you need to set up a copy of your repository that will be dedicated to the client/server (no user access).  
You will need to set up ssh keys such that the repository can update without entering a password.  
I would not recommend having a client and server share the same repository.

###################
## CLIENT/SERVER ##
###################
In the web directory there is a file called battlecode.tar.gz.  Copy this to the directory you would like the client/server to be installed and unzip it.  
You will need to edit the etc/battlecode.conf file to fit your configuration.  
In addition, if you are going to be running the server you will need to copy the file into your /etc directory.  

#############
## RUNNING ##
#############
You must run all commands as root.  To run the client, do 
./run.sh
To run the server, add a -s argument 
To run as a daemon, configure the parameters at the top of the etc/init.d/battlecode file and run that

##################
## INSTALLATION ##
##################
To install, you should edit the configuration of etc/init.d/battlecode at the top of the file.
Then, copy the file into your /etc/init.d/battlecode directory and run
sudo update-rc.d battlecode defaults

###############
## DEBUGGING ##
###############
If you find that there is a bug, set DEBUG=1 in the battlecode.conf file and run the server/client directly using ./run.sh or ./run.sh -s.  The output will contain the stack traces of any exceptions thrown.  
