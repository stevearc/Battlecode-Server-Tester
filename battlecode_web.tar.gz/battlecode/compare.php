<html>
<head>
<title>BoydBoyd</title>
</head>
<body>

<?php
require "setup.php";

if (!$auth) {
	echo "You are not allowed to view this page.";
} else {
	$runid1 = $_POST['runid1'];
	$runid2 = $_POST['runid2'];
	if ($runid1 == "" || $runid2 == "") {
		echo "Must select two runs<br>";
	} else {
		$query = mysql_query("SELECT m.* FROM matches m JOIN runs r ON m.id = r.id WHERE r.id = " . $runid1 . " ORDER BY m.map");
		while ($row = mysql_fetch_array($query)){
			$maps1[$row['map']] = "yes";
			$maps_all[] = $row['map'];
			$files1[$row['map']] = $row['file'];
			$win1[$row['map']] = $row['win'];
		}
		$query = mysql_query("SELECT m.* FROM matches m JOIN runs r ON m.id = r.id WHERE r.id = " . $runid2 . " ORDER BY m.map");
		while ($row = mysql_fetch_array($query)){
			$maps2[$row['map']] = "yes";
			$maps_all[] = $row['map'];
			$files2[$row['map']] = $row['file'];
			$win2[$row['map']] = $row['win'];
		}

		$maps_all = array_unique($maps_all);
		sort($maps_all);

		$query = mysql_query("SELECT id, team_a, team_b, t1.alias a_nick, t2.alias b_nick FROM runs r LEFT JOIN tags t1 ON r.team_a = t1.tag LEFT JOIN tags t2 ON r.team_b = t2.tag WHERE id = " . $runid1);
		$row1 = mysql_fetch_array($query);
		$query = mysql_query("SELECT id, team_a, team_b, t1.alias a_nick, t2.alias b_nick FROM runs r LEFT JOIN tags t1 ON r.team_a = t1.tag LEFT JOIN tags t2 ON r.team_b = t2.tag WHERE id = " . $runid2);
		$row2 = mysql_fetch_array($query);
		echo "<a href=\"index.php\">back</a><br><br>";
		echo "<table border=\"1\">";
		echo "<tr>";
		echo "<th>Team A</th>";
		echo "<th>Team B</th>";
		echo "<th>_____</th>";
		echo "<th>Team A</th>";
		echo "<th>Team B</th>";
		echo "<tr>";

		if ($row1['a_nick'] != "")
			echo "<td>" . $row1['a_nick'] . " (" . $row1['team_a'] . ")</td>";
		else	
			echo "<td>" . $row1['team_a'] . "</td>";
		
		if ($row1['b_nick'] != "")
			echo "<td>" . $row1['b_nick'] . " (" . $row1['team_b'] . ")</td>";
		else	
			echo "<td>" . $row1['team_b'] . "</td>";
		
		echo "<td></td>";

		if ($row2['a_nick'] != "")
			echo "<td>" . $row2['a_nick'] . " (" . $row2['team_a'] . ")</td>";
		else	
			echo "<td>" . $row2['team_a'] . "</td>";
		
		if ($row2['b_nick'] != "")
			echo "<td>" . $row2['b_nick'] . " (" . $row2['team_b'] . ")</td>";
		else	
			echo "<td>" . $row2['team_b'] . "</td>";
		echo "</tr>";
		$query = mysql_query("SELECT sum(win) as wins from matches where id = " . $runid1);
		$row = mysql_fetch_array($query);
		$wins1 = $row['wins'];
		$query = mysql_query("SELECT count(*) as total from matches where id = " . $runid1);
		$row = mysql_fetch_array($query);
		$total1 = $row['total'];
		$losses1 = $total1 - $wins1;
		$query = mysql_query("SELECT sum(win) as wins from matches where id = " . $runid2);
		$row = mysql_fetch_array($query);
		$wins2 = $row['wins'];
		$query = mysql_query("SELECT count(*) as total from matches where id = " . $runid2);
		$row = mysql_fetch_array($query);
		$total2 = $row['total'];
		$losses2 = $total2 - $wins2;
		echo "<tr>";
		echo "<td>" . $wins1 . "</td>";
		echo "<td>" . $losses1 . "</td>";
		echo "<td></td>";
		echo "<td>" . $wins2 . "</td>";
		echo "<td>" . $losses2 . "</td>";
		echo "</tr>";
		echo "</table><br><br>";
		echo "<table border=\"1\">";
		echo "<tr>";
		echo "<th>Map</th>";
		echo "<th>Winner " . $runid1 . "</th>";
		echo "<th>Match " . $runid1 . "</th>";
		echo "<th>Winner " . $runid2 . "</th>";
		echo "<th>Match " . $runid2 . "</th>";
		echo "</tr>";
		foreach ($maps_all as $map) {
			echo "<tr>";
			echo "<td>" . $map . "</td>";
			if ( $maps1[$map] != "" ) {
				if ( $win1[$map] == 1 ) {
					echo "<td>A</td>";
				} else {
					echo "<td>B</td>";
				}
				$filename = substr($files1[$map], strrpos($files1[$map], "/")+1);
				echo "<td> <a href=\"matches/" . $filename . "\">download</a></td>";
				}
			if ( $maps2[$map] != "" ) {
				echo "<td>";
				if ( $win1[$map] != $win2[$map]) {
					echo "<font color='red'>";
				}
				if ( $win2[$map] == 1 ) {
					echo "A";
				} else {
					echo "B";
				}
				if ( $win1[$map] != $win2[$map]) {
					echo "</font>";
				}
				echo "</td>";
				$filename = substr($files2[$map], strrpos($files2[$map], "/")+1);
				echo "<td> <a href=\"matches/" . $filename . "\">download</a></td>";
			} 
			echo "</tr>";
		}
		echo "</table>";
	}

mysql_close($con);
}
?>

</body>
</html>
